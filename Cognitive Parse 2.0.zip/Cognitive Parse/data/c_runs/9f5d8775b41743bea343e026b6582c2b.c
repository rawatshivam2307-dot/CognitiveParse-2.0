#include <stdio.h>

int main() {

    int number;

    printf("Value = %d", number);

    return 0;
}