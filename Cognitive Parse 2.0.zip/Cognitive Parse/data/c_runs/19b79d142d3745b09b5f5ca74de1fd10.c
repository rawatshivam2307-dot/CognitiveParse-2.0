
#include <stdio.h>

int main() {
    printf("broken")
    return 0;
}
