#include <stdio.h>

int main() {
    int num = 5;

    if(num = 10) {
        printf("Equal");
    }

    return 0;
}