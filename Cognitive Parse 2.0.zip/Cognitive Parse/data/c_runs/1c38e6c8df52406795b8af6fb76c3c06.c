#include <stdio.h>

int main() {
    int a = 10, b = 20, c = 30;
    int average;

    average = a + b c / 3;

    printf("Average = %d", average);

    return 0;
}