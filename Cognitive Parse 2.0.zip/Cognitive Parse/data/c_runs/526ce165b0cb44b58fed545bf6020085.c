#include <stdio.h>
int main() {
    printf("c ok\n");
    return 0;
}