#include <stdio.h>

int main() {

    int marks = 85.5;

    printf("Marks = %d", marks);

    return 0;
}