#include <stdio.h>

int main() {
    int num = 5;
    int fact = 0;
    int i;

    for(i = 1; i <= num; i++) {
        fact = fact * i;
    }

    printf("Factorial = %d", fact);

    return 0;
}