#include <stdio.h>

int main() {
    int x = 4 + 2;
    printf("%d\n", x);
    return 0;
}
