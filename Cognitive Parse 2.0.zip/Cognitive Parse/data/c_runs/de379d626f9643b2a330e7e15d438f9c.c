#include <stdio.h>

int main() {

    int total_marks = 500;
    int subjects = 0;

    int average = total_marks / subjects;

    printf("Average = %d", average);

    return 0;
}