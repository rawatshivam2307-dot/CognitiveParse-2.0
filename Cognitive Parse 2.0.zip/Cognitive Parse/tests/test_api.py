﻿import unittest

from backend.app import app
from backend.database import clear_errors, fetch_recent_errors, init_db


class ApiTests(unittest.TestCase):
    def setUp(self):
        init_db()
        clear_errors()
        self.client = app.test_client()

    def test_analyze_valid_code(self):
        code = """
class A:
    def __init__(self, x):
        self.x = x

    def square(self):
        return self.x ** 2
"""
        response = self.client.post("/analyze", json={"code": code})
        self.assertEqual(response.status_code, 200)
        payload = response.get_json()
        self.assertTrue(payload["ok"])
        self.assertIn("node_count", payload["ast"])
        self.assertIn("output", payload)

    def test_analyze_python_code_with_input_returns_output(self):
        code = """
a = int(input("Enter first number: "))
b = int(input("Enter second number: "))

sum = a + b
difference = a - b
product = a * b
division = a / b

print("Addition =", sum)
print("Subtraction =", difference)
print("Multiplication =", product)
print("Division =", division)
"""
        response = self.client.post("/analyze", json={"code": code, "stdin": "10\n2\n"})
        self.assertEqual(response.status_code, 200)
        payload = response.get_json()
        self.assertTrue(payload["ok"])
        self.assertIn("Addition = 12", payload["output"])
        self.assertIn("Division = 5.0", payload["output"])

    def test_analyze_python_code_missing_input_requests_input(self):
        response = self.client.post("/analyze", json={"code": "name = input('Name: ')\nprint(name)\n"})
        self.assertEqual(response.status_code, 422)
        payload = response.get_json()
        self.assertFalse(payload["ok"])
        self.assertEqual(payload["category"], "Input Required")

    def test_analyze_python_code_with_safe_import(self):
        response = self.client.post("/analyze", json={"code": "import math\nprint(math.sqrt(81))\n"})
        self.assertEqual(response.status_code, 200)
        payload = response.get_json()
        self.assertTrue(payload["ok"])
        self.assertEqual(payload["output"], "9.0\n")

    def test_analyze_invalid_code_logs_error(self):
        response = self.client.post("/analyze", json={"code": "for i in range(5) print(i)\n"})
        self.assertEqual(response.status_code, 422)
        payload = response.get_json()
        self.assertFalse(payload["ok"])

        rows = fetch_recent_errors()
        self.assertGreaterEqual(len(rows), 1)
        self.assertIn("category", rows[0])
        self.assertEqual(rows[0]["language"], "python")

    def test_analyze_logical_error_returns_error_and_logs_it(self):
        response = self.client.post("/analyze", json={"code": "print(total)\n"})
        self.assertEqual(response.status_code, 422)
        payload = response.get_json()
        self.assertFalse(payload["ok"])
        self.assertEqual(payload["category"], "Undefined Name")
        self.assertIn("logic_issues", payload)

        rows = fetch_recent_errors()
        self.assertGreaterEqual(len(rows), 1)
        self.assertEqual(rows[0]["category"], "Undefined Name")

    def test_analyze_c_code_returns_program_output(self):
        code = """
#include <stdio.h>

int main() {
    int x = 4 + 2;
    printf("%d\\n", x);
    return 0;
}
"""
        response = self.client.post("/analyze", json={"code": code, "language": "c"})
        self.assertEqual(response.status_code, 200)
        payload = response.get_json()
        self.assertTrue(payload["ok"])
        self.assertEqual(payload["language"], "c")
        self.assertEqual(payload["output"], "6\n")

    def test_analyze_c_code_with_input_returns_output(self):
        code = """
#include <stdio.h>

int main() {
    int a;
    int b;
    scanf("%d %d", &a, &b);
    printf("%d\\n", a + b);
    return 0;
}
"""
        response = self.client.post("/analyze", json={"code": code, "language": "c", "stdin": "10 2\n"})
        self.assertEqual(response.status_code, 200)
        payload = response.get_json()
        self.assertTrue(payload["ok"])
        self.assertEqual(payload["output"], "12\n")

    def test_analyze_c_compile_error_logs_error(self):
        code = """
#include <stdio.h>

int main() {
    printf("broken")
    return 0;
}
"""
        response = self.client.post("/analyze", json={"code": code, "language": "c"})
        self.assertEqual(response.status_code, 422)
        payload = response.get_json()
        self.assertFalse(payload["ok"])
        self.assertEqual(payload["language"], "c")

        rows = fetch_recent_errors()
        self.assertGreaterEqual(len(rows), 1)
        self.assertTrue(rows[0]["category"].startswith("C "))
        self.assertEqual(rows[0]["language"], "c")

    def test_dashboard_api_endpoints(self):
        self.client.post("/analyze", json={"code": "x =\n"})

        stats = self.client.get("/api/stats")
        errors = self.client.get("/api/errors")

        self.assertEqual(stats.status_code, 200)
        self.assertEqual(errors.status_code, 200)

        stats_payload = stats.get_json()
        errors_payload = errors.get_json()

        self.assertIn("categories", stats_payload)
        self.assertIn("errors", errors_payload)

    def test_clear_errors_endpoint(self):
        self.client.post("/analyze", json={"code": "if True print('x')\n"})
        self.assertGreaterEqual(len(fetch_recent_errors()), 1)

        cleared = self.client.post("/api/errors/clear")
        self.assertEqual(cleared.status_code, 200)
        payload = cleared.get_json()
        self.assertTrue(payload["ok"])
        self.assertEqual(len(fetch_recent_errors()), 0)

    def test_performance_report_endpoints(self):
        self.client.post("/analyze", json={"code": "if True print('x')\n"})

        report_json = self.client.get("/api/report")
        self.assertEqual(report_json.status_code, 200)
        payload = report_json.get_json()
        self.assertIn("total_errors", payload)
        self.assertIn("category_distribution", payload)
        self.assertIn("language_totals", payload)
        self.assertIn("category_distribution_by_language", payload)

        report_md = self.client.get("/api/report/markdown")
        self.assertEqual(report_md.status_code, 200)
        self.assertIn("Performance Evaluation Report", report_md.get_data(as_text=True))


if __name__ == "__main__":
    unittest.main()
