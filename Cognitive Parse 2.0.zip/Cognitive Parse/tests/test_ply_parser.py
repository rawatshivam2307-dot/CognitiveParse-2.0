import unittest

from backend.parser import cognitive_parser
from backend.ply_parser import analyze_with_ply


class PlyParserIntegrationTests(unittest.TestCase):
    def test_supported_subset_reports_tokens_and_statements(self):
        result = analyze_with_ply("x = 4 + 2\nprint(x)\n")

        self.assertTrue(result.supported)
        self.assertEqual(result.statement_count, 2)
        self.assertGreater(result.token_count, 0)

    def test_parser_includes_compiler_checks(self):
        result = cognitive_parser.parse_code("x = 4 + 2\nprint(x)\n")
        checks = result.ast["compiler_checks"]

        self.assertTrue(checks["ply_subset_supported"])
        self.assertEqual(checks["statement_count"], 2)
        self.assertGreater(checks["token_count"], 0)

    def test_valid_python_outside_subset_does_not_fail_ast_parse(self):
        result = cognitive_parser.parse_code("def square(value):\n    return value * value\n")
        checks = result.ast["compiler_checks"]

        self.assertTrue(result.valid)
        self.assertFalse(checks["ply_subset_supported"])


if __name__ == "__main__":
    unittest.main()
