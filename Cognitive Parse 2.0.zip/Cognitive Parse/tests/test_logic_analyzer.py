import unittest

from backend.logic_analyzer import analyze_logic


class LogicAnalyzerTests(unittest.TestCase):
    def test_detects_undefined_name(self):
        issues = analyze_logic("print(total)\n")
        self.assertTrue(any(issue.category == "Undefined Name" for issue in issues))

    def test_detects_division_by_zero(self):
        issues = analyze_logic("result = 10 / 0\n")
        self.assertTrue(any(issue.category == "Division By Zero" for issue in issues))

    def test_detects_unreachable_code(self):
        code = """
def value():
    return 4
    print("never")
"""
        issues = analyze_logic(code)
        self.assertTrue(any(issue.category == "Unreachable Code" for issue in issues))

    def test_valid_code_has_no_logic_issues(self):
        code = """
def square(value):
    result = value * value
    return result

print(square(4))
"""
        self.assertEqual(analyze_logic(code), [])


if __name__ == "__main__":
    unittest.main()
