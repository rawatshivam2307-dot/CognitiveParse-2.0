﻿function htmlEscape(value) {
    return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#39;");
}

function drawChartText(ctx, text, x, y, font, align = "left") {
    ctx.save();
    ctx.font = font;
    ctx.textAlign = align;
    ctx.lineJoin = "round";
    ctx.lineWidth = 4;
    ctx.strokeStyle = "rgba(3, 10, 24, 0.86)";
    ctx.fillStyle = "#ffffff";
    ctx.strokeText(text, x, y);
    ctx.fillText(text, x, y);
    ctx.restore();
}

function formatDate(isoLike) {
    if (!isoLike) return "-";
    const safe = isoLike.replace(" ", "T") + "Z";
    const d = new Date(safe);
    if (Number.isNaN(d.getTime())) return isoLike;
    return d.toLocaleString();
}

function focusProgramInput() {
    const inputBox = document.getElementById("stdinInput");
    if (!inputBox) return;

    inputBox.classList.add("needs-input");
    inputBox.scrollIntoView({ behavior: "smooth", block: "center" });
    inputBox.focus();
}

function renderResult(data) {
    const box = document.getElementById("resultBox");
    if (!box) return;

    box.classList.remove("hidden", "ok", "error");

    if (data.ok) {
        const nodeCount = data.ast && typeof data.ast.node_count === "number"
            ? data.ast.node_count
            : Array.isArray(data.ast)
                ? data.ast.length
                : 0;
        const details = data.ast || data.details || {};
        box.classList.add("ok");
        box.innerHTML = `
            <strong>Valid Code</strong>
            <div class="result-grid">
                <div class="result-item"><strong>Status:</strong> No syntax or logical issues detected</div>
                <div class="result-item"><strong>Language:</strong> ${htmlEscape(data.language || "python")}</div>
                ${data.ast ? `<div class="result-item"><strong>Nodes:</strong> ${nodeCount}</div>` : ""}
            </div>
            <section class="terminal-output" aria-label="Program output">
                <div class="terminal-title">Output</div>
                <pre>${htmlEscape(data.output || "No output produced.")}</pre>
            </section>
            <details class="analysis-details">
                <summary>Analysis Details</summary>
                <pre>${htmlEscape(JSON.stringify(details, null, 2))}</pre>
            </details>
        `;
    } else {
        const logicIssues = Array.isArray(data.logic_issues) ? data.logic_issues : [];
        const logicMarkup = logicIssues.length > 1
            ? `
                <div class="issue-list">
                    ${logicIssues.map((issue) => `
                        <article class="issue-item">
                            <div><strong>${htmlEscape(issue.category || "Logical Issue")}</strong> on line ${htmlEscape(issue.line || "N/A")}</div>
                            <p>${htmlEscape(issue.message || "")}</p>
                            <p><strong>Suggestion:</strong> ${htmlEscape(issue.suggestion || "Review this statement.")}</p>
                        </article>
                    `).join("")}
                </div>
            `
            : "";
        box.classList.add("error");
        box.innerHTML = `
            <strong>Issue Detected</strong>
            <div class="result-grid">
                <div class="result-item"><strong>Category:</strong> ${htmlEscape(data.category || "N/A")}</div>
                <div class="result-item"><strong>Line:</strong> ${htmlEscape(data.line || "N/A")}</div>
                <div class="result-item"><strong>Token:</strong> ${htmlEscape(data.token || "N/A")}</div>
                <div class="result-item"><strong>Suggestion:</strong> ${htmlEscape(data.suggestion || "N/A")}</div>
            </div>
            <p><strong>Explanation:</strong> ${htmlEscape(data.explanation || "N/A")}</p>
            ${logicMarkup}
            <section class="terminal-output error-output" aria-label="Program output">
                <div class="terminal-title">Output / Error</div>
                <pre>${htmlEscape(data.output || data.error || "Unknown error")}</pre>
            </section>
        `;

        if (data.category === "Input Required") {
            focusProgramInput();
        }
    }
}

async function handleAnalyzeSubmit(event) {
    event.preventDefault();
    const code = document.getElementById("codeInput").value;
    const stdin = document.getElementById("stdinInput")?.value || "";
    const language = document.getElementById("languageSelect")?.value || "python";

    const response = await fetch("/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code, language, stdin }),
    });

    const data = await response.json();
    renderResult(data);
}

function drawBars(canvas, categories) {
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    const width = canvas.width;
    const height = canvas.height;
    const gridColor = "rgba(219, 232, 255, 0.34)";
    ctx.clearRect(0, 0, width, height);

    if (!categories.length) {
        drawChartText(ctx, "No errors logged yet.", 22, 36, "bold 16px Trebuchet MS");
        return;
    }

    const max = Math.max(...categories.map((item) => item.count));
    const leftPad = 50;
    const bottomPad = 58;
    const chartHeight = height - bottomPad - 20;
    const slot = (width - leftPad - 26) / categories.length;

    ctx.strokeStyle = gridColor;
    ctx.lineWidth = 1;
    for (let i = 0; i <= 4; i += 1) {
        const y = 20 + (chartHeight / 4) * i;
        ctx.beginPath();
        ctx.moveTo(leftPad, y);
        ctx.lineTo(width - 12, y);
        ctx.stroke();
    }

    categories.forEach((item, index) => {
        const x = leftPad + index * slot + 8;
        const barWidth = Math.max(20, slot - 16);
        const barHeight = Math.max(6, Math.floor((item.count / max) * chartHeight));
        const y = 20 + (chartHeight - barHeight);

        const grad = ctx.createLinearGradient(0, y, 0, y + barHeight);
        grad.addColorStop(0, "#1aa58f");
        grad.addColorStop(1, "#1f64af");

        ctx.fillStyle = grad;
        ctx.fillRect(x, y, barWidth, barHeight);

        drawChartText(ctx, String(item.count), x + 4, y - 8, "bold 16px Trebuchet MS");
        drawChartText(ctx, item.category.slice(0, 22), x + 2, height - 28, "bold 13px Trebuchet MS");
    });
}

function drawTrend(canvas, trend) {
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    const width = canvas.width;
    const height = canvas.height;
    const gridColor = "rgba(219, 232, 255, 0.34)";
    ctx.clearRect(0, 0, width, height);

    if (!trend.length) {
        drawChartText(ctx, "No trend data available yet.", 22, 36, "bold 16px Trebuchet MS");
        return;
    }

    const max = Math.max(...trend.map((item) => item.count), 1);
    const leftPad = 52;
    const rightPad = 24;
    const topPad = 22;
    const bottomPad = 54;
    const chartWidth = width - leftPad - rightPad;
    const chartHeight = height - topPad - bottomPad;
    const step = trend.length > 1 ? chartWidth / (trend.length - 1) : chartWidth;

    ctx.strokeStyle = gridColor;
    ctx.lineWidth = 1;
    for (let i = 0; i <= 4; i += 1) {
        const y = topPad + (chartHeight / 4) * i;
        ctx.beginPath();
        ctx.moveTo(leftPad, y);
        ctx.lineTo(width - rightPad, y);
        ctx.stroke();
    }

    const points = trend.map((item, index) => {
        const x = trend.length > 1 ? leftPad + index * step : leftPad + chartWidth / 2;
        const y = topPad + chartHeight - (item.count / max) * chartHeight;
        return { ...item, x, y };
    });

    ctx.strokeStyle = "#1f64af";
    ctx.lineWidth = 3;
    ctx.beginPath();
    points.forEach((point, index) => {
        if (index === 0) ctx.moveTo(point.x, point.y);
        else ctx.lineTo(point.x, point.y);
    });
    ctx.stroke();

    points.forEach((point) => {
        ctx.fillStyle = "#17a58e";
        ctx.beginPath();
        ctx.arc(point.x, point.y, 5, 0, Math.PI * 2);
        ctx.fill();

        drawChartText(ctx, String(point.count), point.x - 4, point.y - 10, "bold 16px Trebuchet MS");
        drawChartText(ctx, String(point.day).slice(5), point.x - 18, height - 26, "bold 13px Trebuchet MS");
    });
}

async function loadDashboard() {
    const pythonCanvas = document.getElementById("pythonCategoryChart");
    const cCanvas = document.getElementById("cCategoryChart");
    const trendCanvas = document.getElementById("trendChart");
    const body = document.querySelector("#errorsTable tbody");
    if (!pythonCanvas || !cCanvas || !body) return;

    const [statsRes, errorsRes, reportRes] = await Promise.all([
        fetch("/api/stats"),
        fetch("/api/errors"),
        fetch("/api/report"),
    ]);

    const statsData = await statsRes.json();
    const errorsData = await errorsRes.json();
    const reportData = await reportRes.json();

    const byLanguage = reportData.category_distribution_by_language || [];
    drawBars(pythonCanvas, byLanguage.filter((item) => item.language === "python"));
    drawBars(cCanvas, byLanguage.filter((item) => item.language === "c"));
    drawTrend(trendCanvas, reportData.daily_trend || []);

    const totalNode = document.getElementById("totalErrors");
    const pythonNode = document.getElementById("pythonErrors");
    const cNode = document.getElementById("cErrors");
    const dominantNode = document.getElementById("dominantCategory");
    const generatedNode = document.getElementById("generatedAt");
    const languageTotals = reportData.language_totals || [];
    const countForLanguage = (language) => {
        const row = languageTotals.find((item) => item.language === language);
        return row ? row.count : 0;
    };

    if (totalNode) totalNode.textContent = String(reportData.total_errors ?? 0);
    if (pythonNode) pythonNode.textContent = String(countForLanguage("python"));
    if (cNode) cNode.textContent = String(countForLanguage("c"));
    if (dominantNode) {
        dominantNode.textContent = reportData.category_distribution?.length
            ? reportData.category_distribution[0].category
            : "N/A";
    }
    if (generatedNode) generatedNode.textContent = reportData.generated_at || "N/A";

    body.innerHTML = "";
    (errorsData.errors || []).forEach((row) => {
        const tr = document.createElement("tr");
        tr.innerHTML = `
            <td>${htmlEscape(formatDate(row.created_at || ""))}</td>
            <td>${htmlEscape(row.language || "python")}</td>
            <td>${htmlEscape(row.category || "")}</td>
            <td>${htmlEscape(row.message || "")}</td>
            <td>${htmlEscape(row.suggestion || "")}</td>
        `;
        body.appendChild(tr);
    });
}

async function clearStoredErrors() {
    const response = await fetch("/api/errors/clear", {
        method: "POST",
    });
    const data = await response.json();
    if (!response.ok || !data.ok) {
        throw new Error(data.error || "Unable to clear stored errors.");
    }
}

function attachDashboardHandlers() {
    const clearBtn = document.getElementById("clearErrorsBtn");

    if (clearBtn) {
        clearBtn.addEventListener("click", async () => {
            const confirmed = window.confirm("Clear all stored error logs from dashboard analytics?");
            if (!confirmed) return;

            clearBtn.disabled = true;
            try {
                await clearStoredErrors();
                await loadDashboard();
            } catch (err) {
                window.alert(err.message || "Failed to clear stored errors.");
            } finally {
                clearBtn.disabled = false;
            }
        });
    }
}

function attachAnalyzerHandlers() {
    const form = document.getElementById("analyzeForm");
    if (!form) return;

    form.addEventListener("submit", handleAnalyzeSubmit);

    const clearBtn = document.getElementById("clearBtn");
    const exampleInputBtn = document.getElementById("exampleInputBtn");
    const input = document.getElementById("codeInput");
    const stdinInput = document.getElementById("stdinInput");
    const languageSelect = document.getElementById("languageSelect");

    if (languageSelect) {
        languageSelect.addEventListener("change", () => {
            if (languageSelect.value === "c") {
                input.placeholder = `Example:
#include <stdio.h>

int main() {
    int x = 4 + 2;
    printf("%d\\n", x);
    return 0;
}`;
            } else {
                input.placeholder = `Example:
x = 4 + 2
print(x)
if x:
`;
            }
        });
    }

    if (stdinInput) {
        stdinInput.addEventListener("input", () => {
            stdinInput.classList.remove("needs-input");
        });
    }

    if (exampleInputBtn && stdinInput) {
        exampleInputBtn.addEventListener("click", () => {
            stdinInput.value = "10\n2";
            stdinInput.classList.remove("needs-input");
            stdinInput.focus();
        });
    }

    clearBtn.addEventListener("click", () => {
        input.value = "";
        if (stdinInput) stdinInput.value = "";
        const box = document.getElementById("resultBox");
        box.classList.add("hidden");
        box.innerHTML = "";
    });
}

window.addEventListener("DOMContentLoaded", () => {
    attachAnalyzerHandlers();
    attachDashboardHandlers();
    loadDashboard();
});
