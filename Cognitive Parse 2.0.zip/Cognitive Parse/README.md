﻿# CognitiveParse

CognitiveParse is a suggestion-based Python syntax error detection system.

## Features
- Native Python syntax parsing using `ast.parse` (broad syntax coverage for your Python version).
- Integrated PLY lexer/parser subset for compiler-design validation and token reporting.
- Logical issue detection for undefined names, division by zero, unreachable code, and unused variables.
- C language support using GCC compilation, warnings-as-errors validation, and captured program output.
- Structured syntax error classification.
- AI-style suggestion engine using lightweight techniques (`difflib` + structural correction patterns).
- SQLite-backed error logging with timestamp, category, token, and line.
- Flask web UI for code analysis.
- Analytics dashboard with category distribution, daily trend chart, and recent error table.
- Performance evaluation report generation (JSON + Markdown).

## Project Structure
- `backend/parser.py`: Python parser wrapper (`ast.parse`) and AST summary output
- `backend/lexer.py`: PLY lexer for compiler-design tokenization
- `backend/ply_parser.py`: PLY parser for beginner-level Python statement subset
- `backend/logic_analyzer.py`: AST-based logical issue detection
- `backend/c_analyzer.py`: C compiler integration and execution output capture
- `backend/error_handler.py`: error categorization and explanation
- `backend/suggestion_engine.py`: correction suggestions
- `backend/database.py`: error logging and analytics queries
- `backend/performance_report.py`: performance summary and markdown report builder
- `backend/app.py`: Flask app and APIs
- `frontend/`: UI and dashboard
- `tests/`: parser and API tests
- `data/sample_programs/`: sample input programs
- `data/reports/`: generated performance reports

## Run
```bash
pip install -r requirements.txt
python backend/app.py
```

Open `http://127.0.0.1:5000`.

## Current Completion Against Phase 2 Template
- PLY lexer/parser integration: completed as a compiler subset check alongside the AST parser.
- Suggestion engine improvements: completed with keyword similarity, missing colon, delimiter, indentation, and incomplete statement guidance.
- Performance report generation: completed through `/api/report`, `/api/report/markdown`, and `backend/performance_report.py`.
- System testing and validation: completed with parser, API, suggestion, logic analyzer, and PLY integration tests.
- UI/UX and charts: completed with analyzer feedback, category chart, daily trend chart, and recent error dashboard.
- Additional language support: C programs can be compiled, validated, executed, and shown with output.

## Tests
```bash
python -m unittest discover -s tests -v
```

## API Endpoints
- `POST /analyze`
- `GET /api/stats`
- `GET /api/errors`
- `GET /api/report`
- `GET /api/report/markdown`
- `GET /dashboard`

## Generate Performance Report File
```bash
python backend/performance_report.py
```

Output: `data/reports/performance_evaluation_report.md`

## Notes
- Parser support tracks the Python version you run the app with.
- If the default database path is not writable, the app falls back to a temp directory database.
- Suggestion logic combines token similarity with rule-based patterns (missing `:`, delimiter balance, indentation, incomplete statements, keyword typos).

