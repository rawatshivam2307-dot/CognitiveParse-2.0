﻿from __future__ import annotations

from pathlib import Path
import re
from typing import Any, Dict, Tuple

from flask import Flask, jsonify, render_template, request

try:
    from .c_analyzer import analyze_c_code
    from .database import ErrorRecord, clear_errors, fetch_category_counts, fetch_recent_errors, init_db, log_error
    from .error_handler import classify_error
    from .executor import ExecutionInputRequired, execute_code
    from .logic_analyzer import analyze_logic
    from .parser import cognitive_parser
    from .performance_report import build_markdown_report, build_performance_summary
    from .suggestion_engine import suggest
except ImportError:
    from c_analyzer import analyze_c_code
    from database import ErrorRecord, clear_errors, fetch_category_counts, fetch_recent_errors, init_db, log_error
    from error_handler import classify_error
    from executor import ExecutionInputRequired, execute_code
    from logic_analyzer import analyze_logic
    from parser import cognitive_parser
    from performance_report import build_markdown_report, build_performance_summary
    from suggestion_engine import suggest

BASE_DIR = Path(__file__).resolve().parents[1]
FRONTEND_DIR = BASE_DIR / "frontend"

app = Flask(__name__, template_folder=str(FRONTEND_DIR), static_folder=str(FRONTEND_DIR), static_url_path="")
init_db()


def _extract_error_context(exc: Exception) -> Tuple[str, str, int, str]:
    if isinstance(exc, SyntaxError):
        token = ""
        line_text = (exc.text or "").rstrip("\n")
        if exc.text and exc.offset and exc.offset > 0:
            idx = exc.offset - 1
            if idx < len(exc.text):
                # Prefer the full identifier around the offset when possible.
                match = re.search(r"[A-Za-z_][A-Za-z_0-9]*", exc.text[idx:])
                if match and match.start() == 0:
                    token = match.group(0)
                else:
                    token = exc.text[idx].strip()

        line_no = int(exc.lineno or 0)
        message = exc.msg or str(exc)
        return message, token, line_no, line_text

    message = str(exc)
    return message, "", 0, ""


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/dashboard")
def dashboard():
    return render_template("dashboard.html")


@app.route("/api/stats")
def api_stats():
    return jsonify({"categories": fetch_category_counts()})


@app.route("/api/errors")
def api_errors():
    return jsonify({"errors": fetch_recent_errors(limit=30)})


@app.route("/api/errors/clear", methods=["POST"])
def api_clear_errors():
    clear_errors()
    return jsonify({"ok": True, "message": "Stored errors cleared."})


@app.route("/api/report")
def api_report():
    return jsonify(build_performance_summary())


@app.route("/api/report/markdown")
def api_report_markdown():
    summary = build_performance_summary()
    return build_markdown_report(summary), 200, {"Content-Type": "text/markdown; charset=utf-8"}


@app.route("/analyze", methods=["POST"])
def analyze():
    payload: Dict[str, Any] = request.get_json(silent=True) or {}
    code = payload.get("code") or request.form.get("code") or ""
    stdin = payload.get("stdin") or request.form.get("stdin") or ""
    language = (payload.get("language") or request.form.get("language") or "python").strip().lower()

    if not code.strip():
        return jsonify({"ok": False, "error": "Code input is empty."}), 400

    if language not in {"python", "c"}:
        return jsonify({"ok": False, "error": f"Unsupported language: {language}"}), 400

    if language == "c":
        result = analyze_c_code(code, BASE_DIR, stdin=stdin)
        if not result.ok:
            log_error(
                ErrorRecord(
                    message=result.message,
                    category=result.category,
                    suggestion=result.suggestion,
                    explanation=result.explanation,
                    line_no=result.line,
                    token="",
                    language="c",
                )
            )
            return (
                jsonify(
                    {
                        "ok": False,
                        "language": "c",
                        "error": result.message,
                        "category": result.category,
                        "explanation": result.explanation,
                        "suggestion": result.suggestion,
                        "line": result.line,
                        "token": "",
                        "output": result.output,
                        "details": result.details,
                    }
                ),
                422,
            )

        return jsonify(
            {
                "ok": True,
                "language": "c",
                "message": result.message,
                "output": result.output,
                "details": result.details,
                "logic_issues": [],
            }
        )

    try:
        result = cognitive_parser.parse_code(code)
        logic_issues = analyze_logic(code)
        if logic_issues:
            for issue in logic_issues:
                log_error(
                    ErrorRecord(
                        message=issue.message,
                        category=issue.category,
                        suggestion=issue.suggestion,
                        explanation=issue.message,
                        line_no=issue.line,
                        token="",
                        language="python",
                    )
                )

            first_issue = logic_issues[0]
            return (
                jsonify(
                    {
                        "ok": False,
                        "language": "python",
                        "error": first_issue.message,
                        "category": first_issue.category,
                        "explanation": first_issue.message,
                        "suggestion": first_issue.suggestion,
                        "line": first_issue.line,
                        "token": "",
                        "logic_issues": [issue.__dict__ for issue in logic_issues],
                        "ast": result.ast,
                    }
                ),
                422,
            )

        try:
            execution = execute_code(code, stdin=stdin)
        except ExecutionInputRequired as exc:
            message = "Program input is required."
            suggestion = "Enter the required input values in the Program Input box, one value per line."
            log_error(
                ErrorRecord(
                    message=message,
                    category="Input Required",
                    suggestion=suggestion,
                    explanation=f"The program called input({exc.prompt!r}) but no matching input value was provided.",
                    line_no=0,
                    token="input",
                    language="python",
                )
            )
            return (
                jsonify(
                    {
                        "ok": False,
                        "language": "python",
                        "error": message,
                        "category": "Input Required",
                        "explanation": f"The program called input({exc.prompt!r}) but no matching input value was provided.",
                        "suggestion": suggestion,
                        "line": 0,
                        "token": "input",
                    }
                ),
                422,
            )
        except Exception as exc:
            message = str(exc)
            suggestion = "Review the runtime operation that failed and provide valid input values if the program asks for input."
            log_error(
                ErrorRecord(
                    message=message,
                    category="Runtime Error",
                    suggestion=suggestion,
                    explanation="The code passed syntax and logical checks, but failed while running.",
                    line_no=0,
                    token="",
                    language="python",
                )
            )
            return (
                jsonify(
                    {
                        "ok": False,
                        "language": "python",
                        "error": message,
                        "category": "Runtime Error",
                        "explanation": "The code passed syntax and logical checks, but failed while running.",
                        "suggestion": suggestion,
                        "line": 0,
                        "token": "",
                    }
                ),
                422,
            )
        return jsonify(
            {
                "ok": True,
                "language": "python",
                "message": result.message,
                "ast": result.ast,
                "logic_issues": [],
                "output": execution.output,
            }
        )
    except Exception as exc:
        message, token, line_no, line_text = _extract_error_context(exc)

        details = classify_error(message, token)
        suggestion = suggest(token, message, line_text=line_text)

        log_error(
            ErrorRecord(
                message=message,
                category=details.category,
                suggestion=suggestion,
                explanation=details.explanation,
                line_no=line_no,
                token=token,
                language="python",
            )
        )

        return (
            jsonify(
                {
                    "ok": False,
                    "language": "python",
                    "error": message,
                    "category": details.category,
                    "explanation": details.explanation,
                    "suggestion": suggestion,
                    "line": line_no,
                    "token": token,
                }
            ),
            422,
        )


if __name__ == "__main__":
    app.run(debug=True)
