from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import re
import subprocess
import uuid
from typing import Dict


@dataclass
class CAnalysisResult:
    ok: bool
    category: str
    message: str
    explanation: str
    suggestion: str
    line: int
    output: str
    details: Dict[str, object]


def _parse_gcc_diagnostic(stderr: str) -> tuple[int, str]:
    match = re.search(r":(\d+):\d+:\s+(?:error|warning):\s+(.+)", stderr)
    if not match:
        return 0, stderr.strip() or "C compilation failed."
    return int(match.group(1)), match.group(2).strip()


def _suggest_c_fix(message: str) -> str:
    lower = message.lower()
    if "expected" in lower and ";" in lower:
        return "Check whether a semicolon is missing before this line."
    if "undeclared" in lower:
        return "Declare the variable before using it or check the spelling."
    if "undefined reference" in lower and "main" in lower:
        return "Add an int main() function as the program entry point."
    if "division by zero" in lower:
        return "Use a non-zero divisor or guard the division with an if condition."
    if "implicit declaration" in lower:
        return "Include the correct header file or declare the function before calling it."
    return "Review the reported C compiler message and correct the highlighted line."


def _cleanup(paths: list[Path]) -> None:
    for path in paths:
        try:
            path.unlink(missing_ok=True)
        except OSError:
            pass


def analyze_c_code(code: str, workspace: Path, stdin: str = "") -> CAnalysisResult:
    run_dir = workspace / "data" / "c_runs"
    run_dir.mkdir(parents=True, exist_ok=True)

    run_id = uuid.uuid4().hex
    source_path = run_dir / f"{run_id}.c"
    exe_path = run_dir / f"{run_id}.exe"
    source_path.write_text(code, encoding="utf-8")

    compile_cmd = [
        "gcc",
        "-std=c11",
        "-Wall",
        "-Wextra",
        "-Werror",
        str(source_path),
        "-o",
        str(exe_path),
    ]

    try:
        compiled = subprocess.run(
            compile_cmd,
            capture_output=True,
            text=True,
            timeout=10,
            check=False,
        )
    except subprocess.TimeoutExpired:
        _cleanup([source_path, exe_path])
        return CAnalysisResult(
            ok=False,
            category="C Compilation Timeout",
            message="C compilation timed out.",
            explanation="The compiler took too long to finish.",
            suggestion="Check for unusually large code or compiler-blocking constructs.",
            line=0,
            output="",
            details={"language": "c"},
        )

    if compiled.returncode != 0:
        line, message = _parse_gcc_diagnostic(compiled.stderr)
        category = "C Logical Error" if "warning:" in compiled.stderr else "C Syntax Error"
        _cleanup([source_path, exe_path])
        return CAnalysisResult(
            ok=False,
            category=category,
            message=message,
            explanation=compiled.stderr.strip(),
            suggestion=_suggest_c_fix(message),
            line=line,
            output="",
            details={"language": "c", "compiler": "gcc", "stderr": compiled.stderr},
        )

    try:
        executed = subprocess.run(
            [str(exe_path)],
            input=stdin,
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except subprocess.TimeoutExpired:
        _cleanup([source_path, exe_path])
        return CAnalysisResult(
            ok=False,
            category="C Runtime Error",
            message="Program execution timed out.",
            explanation="The C program did not finish within the execution limit.",
            suggestion="Check loops and input waits that may prevent the program from ending.",
            line=0,
            output="",
            details={"language": "c", "compiler": "gcc"},
        )

    if executed.returncode != 0:
        _cleanup([source_path, exe_path])
        return CAnalysisResult(
            ok=False,
            category="C Runtime Error",
            message=f"Program exited with code {executed.returncode}.",
            explanation=executed.stderr.strip() or "The compiled C program ended with a non-zero status.",
            suggestion="Check runtime operations such as invalid memory access, bad input, or failed assertions.",
            line=0,
            output=executed.stdout,
            details={"language": "c", "compiler": "gcc", "stderr": executed.stderr},
        )

    result = CAnalysisResult(
        ok=True,
        category="",
        message="Valid C program",
        explanation="C program compiled and executed successfully.",
        suggestion="",
        line=0,
        output=executed.stdout,
        details={
            "language": "c",
            "compiler": "gcc",
            "compile_command": " ".join(compile_cmd),
        },
    )
    _cleanup([source_path, exe_path])
    return result
