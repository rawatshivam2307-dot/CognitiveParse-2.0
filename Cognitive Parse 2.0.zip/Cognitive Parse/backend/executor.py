from __future__ import annotations

from contextlib import redirect_stdout
from dataclasses import dataclass
from io import StringIO
import importlib
from typing import Any, Dict, List


@dataclass
class ExecutionResult:
    output: str


class ExecutionInputRequired(Exception):
    def __init__(self, prompt: str) -> None:
        super().__init__("Program input is required.")
        self.prompt = prompt


SAFE_BUILTINS: Dict[str, Any] = {
    "__build_class__": __build_class__,
    "abs": abs,
    "all": all,
    "any": any,
    "bool": bool,
    "dict": dict,
    "enumerate": enumerate,
    "Exception": Exception,
    "filter": filter,
    "float": float,
    "input": None,
    "int": int,
    "isinstance": isinstance,
    "len": len,
    "list": list,
    "map": map,
    "max": max,
    "min": min,
    "object": object,
    "print": print,
    "pow": pow,
    "range": range,
    "reversed": reversed,
    "round": round,
    "set": set,
    "sorted": sorted,
    "str": str,
    "sum": sum,
    "tuple": tuple,
    "type": type,
    "ValueError": ValueError,
    "zip": zip,
}

ALLOWED_IMPORTS = {
    "collections",
    "datetime",
    "decimal",
    "fractions",
    "functools",
    "itertools",
    "math",
    "operator",
    "random",
    "re",
    "statistics",
    "string",
}


def _safe_import(name: str, globals=None, locals=None, fromlist=(), level: int = 0):
    root_name = name.split(".", 1)[0]
    if level != 0 or root_name not in ALLOWED_IMPORTS:
        raise ImportError(f"Import of '{name}' is not allowed in this execution sandbox.")
    return importlib.import_module(name)


def execute_code(code: str, stdin: str = "") -> ExecutionResult:
    output = StringIO()
    input_lines: List[str] = stdin.splitlines()
    input_index = 0

    def safe_input(prompt: str = "") -> str:
        nonlocal input_index
        if prompt:
            print(prompt, end="")
        if input_index >= len(input_lines):
            raise ExecutionInputRequired(prompt)
        value = input_lines[input_index]
        input_index += 1
        print(value)
        return value

    builtins_env = dict(SAFE_BUILTINS)
    builtins_env["__import__"] = _safe_import
    builtins_env["input"] = safe_input
    globals_env: Dict[str, Any] = {
        "__builtins__": builtins_env,
        "__name__": "__cognitiveparse_user_code__",
    }
    locals_env: Dict[str, Any] = {}

    with redirect_stdout(output):
        exec(compile(code, "<cognitiveparse>", "exec"), globals_env, locals_env)

    return ExecutionResult(output=output.getvalue())
