from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List

import ply.yacc as yacc

try:
    from .lexer import build_lexer, tokens
except ImportError:
    from lexer import build_lexer, tokens


class PlySubsetSyntaxError(SyntaxError):
    pass


@dataclass
class PlyAnalysisResult:
    supported: bool
    message: str
    token_count: int
    statement_count: int
    tokens: List[Dict[str, Any]]


precedence = (
    ("left", "EQ", "NE", "LT", "LE", "GT", "GE"),
    ("left", "PLUS", "MINUS"),
    ("left", "TIMES", "DIVIDE"),
)


def p_program(p):
    """program : statements
    | empty"""
    p[0] = p[1] or []


def p_statements_multiple(p):
    "statements : statements statement_separator statement"
    p[0] = p[1] + ([p[3]] if p[3] else [])


def p_statements_single(p):
    "statements : statement"
    p[0] = [p[1]] if p[1] else []


def p_statement_separator(p):
    """statement_separator : NEWLINE
    | statement_separator NEWLINE"""


def p_statement(p):
    """statement : assignment
    | print_call
    | if_statement
    | while_statement
    | return_statement
    | expression
    | empty"""
    p[0] = p[1]


def p_assignment(p):
    "assignment : ID EQUALS expression"
    p[0] = ("assign", p[1], p[3])


def p_print_call(p):
    "print_call : PRINT LPAREN arguments RPAREN"
    p[0] = ("print", p[3])


def p_if_statement(p):
    "if_statement : IF expression COLON"
    p[0] = ("if", p[2])


def p_while_statement(p):
    "while_statement : WHILE expression COLON"
    p[0] = ("while", p[2])


def p_return_statement(p):
    "return_statement : RETURN expression"
    p[0] = ("return", p[2])


def p_arguments_multiple(p):
    "arguments : arguments COMMA expression"
    p[0] = p[1] + [p[3]]


def p_arguments_single(p):
    "arguments : expression"
    p[0] = [p[1]]


def p_arguments_empty(p):
    "arguments : empty"
    p[0] = []


def p_expression_binop(p):
    """expression : expression PLUS expression
    | expression MINUS expression
    | expression TIMES expression
    | expression DIVIDE expression
    | expression EQ expression
    | expression NE expression
    | expression LT expression
    | expression LE expression
    | expression GT expression
    | expression GE expression"""
    p[0] = ("binop", p[2], p[1], p[3])


def p_expression_group(p):
    "expression : LPAREN expression RPAREN"
    p[0] = p[2]


def p_expression_list(p):
    "expression : LBRACKET arguments RBRACKET"
    p[0] = ("list", p[2])


def p_expression_value(p):
    """expression : ID
    | NUMBER
    | STRING
    | TRUE
    | FALSE
    | NONE"""
    p[0] = ("value", p[1])


def p_empty(p):
    "empty :"
    p[0] = None


def p_error(p):
    if p:
        raise PlySubsetSyntaxError(f"PLY parser stopped near '{p.value}' on line {p.lineno}.")
    raise PlySubsetSyntaxError("PLY parser stopped at end of input.")


def _tokenize(code: str) -> List[Dict[str, Any]]:
    lexer = build_lexer()
    lexer.input(code)
    result: List[Dict[str, Any]] = []
    while True:
        token = lexer.token()
        if not token:
            break
        if token.type == "NEWLINE":
            continue
        result.append(
            {
                "type": token.type,
                "value": token.value,
                "line": token.lineno,
                "position": token.lexpos,
            }
        )
    return result


def analyze_with_ply(code: str) -> PlyAnalysisResult:
    try:
        token_stream = _tokenize(code)
    except SyntaxError as exc:
        return PlyAnalysisResult(
            supported=False,
            message=f"Code is valid Python, but outside the current PLY subset: {exc}",
            token_count=0,
            statement_count=0,
            tokens=[],
        )

    parser = yacc.yacc(start="program", debug=False, write_tables=False, errorlog=yacc.NullLogger())
    try:
        statements = parser.parse(code, lexer=build_lexer())
    except PlySubsetSyntaxError as exc:
        return PlyAnalysisResult(
            supported=False,
            message=f"Code is valid Python, but outside the current PLY subset: {exc}",
            token_count=len(token_stream),
            statement_count=0,
            tokens=token_stream,
        )

    return PlyAnalysisResult(
        supported=True,
        message="Code matched the integrated PLY lexer/parser subset.",
        token_count=len(token_stream),
        statement_count=len(statements or []),
        tokens=token_stream,
    )
