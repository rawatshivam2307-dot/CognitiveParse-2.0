from __future__ import annotations

import ast
import builtins
from dataclasses import dataclass
from typing import Dict, Iterable, List, Set


@dataclass
class LogicIssue:
    category: str
    message: str
    line: int
    suggestion: str


class _Scope:
    def __init__(self, initial_names: Iterable[str] = ()) -> None:
        self.defined: Set[str] = set(initial_names)
        self.used: Set[str] = set()
        self.assigned: Set[str] = set()
        self.assigned_lines: Dict[str, int] = {}


class LogicAnalyzer(ast.NodeVisitor):
    def __init__(self) -> None:
        self.issues: List[LogicIssue] = []
        self.scopes: List[_Scope] = [_Scope(dir(builtins))]

    @property
    def scope(self) -> _Scope:
        return self.scopes[-1]

    def _add_issue(self, category: str, message: str, node: ast.AST, suggestion: str) -> None:
        self.issues.append(
            LogicIssue(
                category=category,
                message=message,
                line=getattr(node, "lineno", 0),
                suggestion=suggestion,
            )
        )

    def _define_target(self, target: ast.AST) -> None:
        if isinstance(target, ast.Name):
            self.scope.defined.add(target.id)
            self.scope.assigned.add(target.id)
            self.scope.assigned_lines[target.id] = getattr(target, "lineno", 0)
            return
        if isinstance(target, (ast.Tuple, ast.List)):
            for elt in target.elts:
                self._define_target(elt)
            return
        if isinstance(target, ast.Starred):
            self._define_target(target.value)

    def _check_unreachable(self, statements: List[ast.stmt]) -> None:
        terminated = False
        for statement in statements:
            if terminated:
                self._add_issue(
                    "Unreachable Code",
                    "This statement appears after code that exits the current block.",
                    statement,
                    "Move the statement before the exit point or remove it if it is not needed.",
                )
                terminated = False

            self.visit(statement)
            terminated = isinstance(statement, (ast.Return, ast.Raise, ast.Break, ast.Continue))

    def _enter_function_scope(self, node: ast.FunctionDef | ast.AsyncFunctionDef) -> None:
        self.scope.defined.add(node.name)
        arg_names = [arg.arg for arg in node.args.posonlyargs + node.args.args + node.args.kwonlyargs]
        if node.args.vararg:
            arg_names.append(node.args.vararg.arg)
        if node.args.kwarg:
            arg_names.append(node.args.kwarg.arg)

        self.scopes.append(_Scope([*dir(builtins), *arg_names]))
        self._check_unreachable(node.body)
        self._check_unused_assignments()
        self.scopes.pop()

    def _check_unused_assignments(self) -> None:
        unused = sorted(name for name in self.scope.assigned - self.scope.used if not name.startswith("_"))
        for name in unused:
            self.issues.append(
                LogicIssue(
                    category="Unused Variable",
                    message=f"'{name}' is assigned but never used.",
                    line=self.scope.assigned_lines.get(name, 0),
                    suggestion="Use the value later in the program or remove the assignment.",
                )
            )

    def visit_Module(self, node: ast.Module) -> None:
        self._check_unreachable(node.body)
        self._check_unused_assignments()

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        for decorator in node.decorator_list:
            self.visit(decorator)
        for default in node.args.defaults + node.args.kw_defaults:
            if default:
                self.visit(default)
        self._enter_function_scope(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self.visit_FunctionDef(node)

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        self.scope.defined.add(node.name)
        for base in node.bases:
            self.visit(base)
        self.scopes.append(_Scope([*dir(builtins), node.name]))
        self._check_unreachable(node.body)
        self._check_unused_assignments()
        self.scopes.pop()

    def visit_Assign(self, node: ast.Assign) -> None:
        self.visit(node.value)
        for target in node.targets:
            self._define_target(target)

    def visit_AnnAssign(self, node: ast.AnnAssign) -> None:
        if node.value:
            self.visit(node.value)
        self._define_target(node.target)

    def visit_AugAssign(self, node: ast.AugAssign) -> None:
        self.visit(node.target)
        self.visit(node.value)
        self._define_target(node.target)

    def visit_For(self, node: ast.For) -> None:
        self.visit(node.iter)
        self._define_target(node.target)
        self._check_unreachable(node.body)
        self._check_unreachable(node.orelse)

    def visit_With(self, node: ast.With) -> None:
        for item in node.items:
            self.visit(item.context_expr)
            if item.optional_vars:
                self._define_target(item.optional_vars)
        self._check_unreachable(node.body)

    def visit_Import(self, node: ast.Import) -> None:
        for alias in node.names:
            self.scope.defined.add(alias.asname or alias.name.split(".")[0])

    def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
        for alias in node.names:
            self.scope.defined.add(alias.asname or alias.name)

    def visit_Name(self, node: ast.Name) -> None:
        if isinstance(node.ctx, ast.Load):
            self.scope.used.add(node.id)
            if node.id not in self.scope.defined:
                self._add_issue(
                    "Undefined Name",
                    f"'{node.id}' is used before it is defined.",
                    node,
                    "Define the variable before using it or check the spelling.",
                )

    def visit_BinOp(self, node: ast.BinOp) -> None:
        if isinstance(node.op, (ast.Div, ast.FloorDiv, ast.Mod)) and isinstance(node.right, ast.Constant):
            if node.right.value == 0:
                self._add_issue(
                    "Division By Zero",
                    "This expression divides by zero.",
                    node,
                    "Use a non-zero divisor or guard the operation with a condition.",
                )
        self.generic_visit(node)


def analyze_logic(code: str) -> List[LogicIssue]:
    tree = ast.parse(code if code.endswith("\n") else f"{code}\n", mode="exec")
    analyzer = LogicAnalyzer()
    analyzer.visit(tree)
    return analyzer.issues
